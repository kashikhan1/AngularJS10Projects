'use strict';

module.exports = {
  // Development assets
};
